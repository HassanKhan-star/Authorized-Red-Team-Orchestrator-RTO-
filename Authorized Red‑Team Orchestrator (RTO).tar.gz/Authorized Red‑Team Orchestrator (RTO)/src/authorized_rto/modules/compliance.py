"""Logging and compliance module for authorized red team operations."""

import logging
import json
from datetime import datetime
from pathlib import Path
from typing import Dict, Any, Optional, List
import hashlib


class ComplianceLogger:
    """Handles logging and compliance tracking for red team operations."""

    def __init__(self, log_dir: str = "logs"):
        self.log_dir = Path(log_dir)
        self.log_dir.mkdir(exist_ok=True)

        # Set up logging
        self.logger = logging.getLogger('rto_compliance')
        self.logger.setLevel(logging.INFO)

        # File handler for compliance logs
        log_file = self.log_dir / f"rto_compliance_{datetime.now().strftime('%Y%m%d')}.log"
        file_handler = logging.FileHandler(log_file)
        file_handler.setLevel(logging.INFO)

        # Formatter
        formatter = logging.Formatter(
            '%(asctime)s - %(name)s - %(levelname)s - %(message)s'
        )
        file_handler.setFormatter(formatter)

        self.logger.addHandler(file_handler)

        # Activity log for audit trail
        self.activity_log = []

    def log_operation_start(self, operation: str, target: str, operator: str, scope_id: str):
        """Log the start of a red team operation."""
        operation_id = self._generate_operation_id(operation, target, scope_id)

        log_entry = {
            'timestamp': datetime.now().isoformat(),
            'operation_id': operation_id,
            'event_type': 'operation_start',
            'operation': operation,
            'target': target,
            'operator': operator,
            'scope_id': scope_id,
            'status': 'in_progress'
        }

        self.activity_log.append(log_entry)
        self.logger.info(f"Operation started: {operation} on {target} (ID: {operation_id})")

        return operation_id

    def log_operation_complete(self, operation_id: str, results: Dict[str, Any], success: bool = True):
        """Log the completion of a red team operation."""
        log_entry = {
            'timestamp': datetime.now().isoformat(),
            'operation_id': operation_id,
            'event_type': 'operation_complete',
            'results_summary': self._summarize_results(results),
            'success': success,
            'status': 'completed'
        }

        self.activity_log.append(log_entry)
        status_msg = "successfully" if success else "with errors"
        self.logger.info(f"Operation completed {status_msg}: {operation_id}")

    def log_scope_validation(self, target: str, allowed: bool, scope_rules: Dict):
        """Log scope validation checks."""
        log_entry = {
            'timestamp': datetime.now().isoformat(),
            'event_type': 'scope_validation',
            'target': target,
            'allowed': allowed,
            'scope_rules': scope_rules
        }

        self.activity_log.append(log_entry)

        if not allowed:
            self.logger.warning(f"Scope violation attempt: {target} not in authorized scope")
        else:
            self.logger.info(f"Scope validation passed: {target}")

    def log_vulnerability_found(self, vulnerability: Dict, operation_id: str):
        """Log discovery of a vulnerability."""
        log_entry = {
            'timestamp': datetime.now().isoformat(),
            'operation_id': operation_id,
            'event_type': 'vulnerability_found',
            'severity': vulnerability.get('severity'),
            'type': vulnerability.get('type'),
            'description': vulnerability.get('description'),
            'target': vulnerability.get('target', 'unknown'),
            'port': vulnerability.get('port'),
            'service': vulnerability.get('service')
        }

        self.activity_log.append(log_entry)
        self.logger.warning(f"Vulnerability found: {vulnerability.get('description')} "
                          f"(Severity: {vulnerability.get('severity')})")

    def log_error(self, operation_id: str, error: str, context: Dict = None):
        """Log errors during operations."""
        log_entry = {
            'timestamp': datetime.now().isoformat(),
            'operation_id': operation_id,
            'event_type': 'error',
            'error': error,
            'context': context or {}
        }

        self.activity_log.append(log_entry)
        self.logger.error(f"Operation error: {error}")

    def generate_audit_report(self, start_date: str = None, end_date: str = None) -> Dict:
        """Generate an audit report for the specified date range."""
        # Filter activities by date range
        filtered_activities = self.activity_log

        if start_date:
            start = datetime.fromisoformat(start_date)
            filtered_activities = [a for a in filtered_activities
                                 if datetime.fromisoformat(a['timestamp']) >= start]

        if end_date:
            end = datetime.fromisoformat(end_date)
            filtered_activities = [a for a in filtered_activities
                                 if datetime.fromisoformat(a['timestamp']) <= end]

        # Generate statistics
        stats = {
            'total_activities': len(filtered_activities),
            'operations_started': len([a for a in filtered_activities
                                     if a['event_type'] == 'operation_start']),
            'operations_completed': len([a for a in filtered_activities
                                       if a['event_type'] == 'operation_complete']),
            'vulnerabilities_found': len([a for a in filtered_activities
                                        if a['event_type'] == 'vulnerability_found']),
            'scope_violations': len([a for a in filtered_activities
                                   if a['event_type'] == 'scope_validation' and not a['allowed']]),
            'errors': len([a for a in filtered_activities
                          if a['event_type'] == 'error'])
        }

        audit_report = {
            'report_period': {
                'start_date': start_date,
                'end_date': end_date
            },
            'generated_at': datetime.now().isoformat(),
            'statistics': stats,
            'activities': filtered_activities
        }

        # Save audit report
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        audit_file = self.log_dir / f"rto_audit_{timestamp}.json"
        with open(audit_file, 'w') as f:
            json.dump(audit_report, f, indent=2)

        return audit_report

    def _generate_operation_id(self, operation: str, target: str, scope_id: str) -> str:
        """Generate a unique operation ID."""
        data = f"{operation}_{target}_{scope_id}_{datetime.now().isoformat()}"
        return hashlib.md5(data.encode()).hexdigest()[:8]

    def _summarize_results(self, results: Dict[str, Any]) -> Dict:
        """Create a summary of operation results."""
        if isinstance(results, dict):
            summary = {}
            for key, value in results.items():
                if isinstance(value, list):
                    summary[key] = f"{len(value)} items"
                elif isinstance(value, dict):
                    summary[key] = f"{len(value)} entries"
                else:
                    summary[key] = str(value)[:100]  # Truncate long values
            return summary
        return {'summary': 'Operation completed'}

    def get_recent_activities(self, limit: int = 10) -> List[Dict]:
        """Get the most recent activities."""
        return self.activity_log[-limit:] if self.activity_log else []

    def export_activities(self, filepath: str):
        """Export all activities to a file."""
        export_path = Path(filepath)
        with open(export_path, 'w') as f:
            json.dump(self.activity_log, f, indent=2)
        self.logger.info(f"Activities exported to {export_path}")