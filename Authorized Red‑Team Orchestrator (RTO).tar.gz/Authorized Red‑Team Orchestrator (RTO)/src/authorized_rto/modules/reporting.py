"""Reporting module for authorized red team operations."""

import json
import csv
import logging
from typing import Dict, List, Any
from datetime import datetime
from pathlib import Path

logger = logging.getLogger(__name__)


class ReportGenerator:
    """Generates comprehensive reports for red team operations."""

    def __init__(self, output_dir: str = "reports"):
        self.output_dir = Path(output_dir)
        self.output_dir.mkdir(exist_ok=True)

    def generate_comprehensive_report(self,
                                   reconnaissance_results: Dict,
                                   vulnerability_findings: List[Dict],
                                   scope_info: Dict,
                                   operation_metadata: Dict) -> str:
        """Generate a comprehensive red team report."""

        report_data = {
            'report_metadata': {
                'generated_at': datetime.now().isoformat(),
                'report_type': 'Authorized Red Team Assessment',
                'version': '1.0',
                **operation_metadata
            },
            'scope': scope_info,
            'reconnaissance': reconnaissance_results,
            'vulnerabilities': vulnerability_findings,
            'summary': self._generate_summary(vulnerability_findings),
            'recommendations': self._generate_recommendations(vulnerability_findings)
        }

        # Generate multiple report formats
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        base_filename = f"rto_report_{timestamp}"

        # JSON report
        json_file = self.output_dir / f"{base_filename}.json"
        with open(json_file, 'w') as f:
            json.dump(report_data, f, indent=2)

        # CSV report for vulnerabilities
        csv_file = self.output_dir / f"{base_filename}_vulnerabilities.csv"
        self._generate_csv_report(vulnerability_findings, csv_file)

        # Text report
        text_file = self.output_dir / f"{base_filename}.txt"
        self._generate_text_report(report_data, text_file)

        logger.info(f"Reports generated: {json_file}, {csv_file}, {text_file}")
        return str(json_file)

    def _generate_summary(self, findings: List[Dict]) -> Dict:
        """Generate summary statistics."""
        severity_counts = {'critical': 0, 'high': 0, 'medium': 0, 'low': 0, 'info': 0}
        type_counts = {}

        for finding in findings:
            severity = finding.get('severity', 'info')
            finding_type = finding.get('type', 'unknown')

            severity_counts[severity] += 1
            type_counts[finding_type] = type_counts.get(finding_type, 0) + 1

        return {
            'total_findings': len(findings),
            'severity_distribution': severity_counts,
            'finding_types': type_counts,
            'risk_assessment': self._assess_risk(severity_counts)
        }

    def _assess_risk(self, severity_counts: Dict) -> str:
        """Assess overall risk level."""
        critical = severity_counts.get('critical', 0)
        high = severity_counts.get('high', 0)
        medium = severity_counts.get('medium', 0)

        if critical > 0:
            return "CRITICAL - Immediate attention required"
        elif high > 2:
            return "HIGH - Urgent remediation needed"
        elif high > 0 or medium > 3:
            return "MEDIUM - Remediation recommended"
        elif medium > 0:
            return "LOW - Minor issues found"
        else:
            return "INFO - No significant issues found"

    def _generate_recommendations(self, findings: List[Dict]) -> List[Dict]:
        """Generate remediation recommendations."""
        recommendations = []

        # Group findings by type
        by_type = {}
        for finding in findings:
            finding_type = finding.get('type', 'unknown')
            if finding_type not in by_type:
                by_type[finding_type] = []
            by_type[finding_type].append(finding)

        # Generate recommendations based on finding types
        for finding_type, type_findings in by_type.items():
            if finding_type == 'information_disclosure':
                recommendations.append({
                    'priority': 'medium',
                    'category': 'Information Disclosure',
                    'recommendation': 'Remove or obfuscate server banners and version information',
                    'affected_items': len(type_findings)
                })
            elif finding_type == 'outdated_software':
                recommendations.append({
                    'priority': 'high',
                    'category': 'Software Updates',
                    'recommendation': 'Update all software to latest stable versions',
                    'affected_items': len(type_findings)
                })
            elif finding_type == 'certificate_issue':
                recommendations.append({
                    'priority': 'critical',
                    'category': 'SSL/TLS Certificates',
                    'recommendation': 'Renew expired certificates and implement proper certificate management',
                    'affected_items': len(type_findings)
                })
            elif finding_type == 'misconfiguration':
                recommendations.append({
                    'priority': 'medium',
                    'category': 'Configuration',
                    'recommendation': 'Review and harden service configurations',
                    'affected_items': len(type_findings)
                })

        return sorted(recommendations, key=lambda x: self._priority_value(x['priority']), reverse=True)

    def _priority_value(self, priority: str) -> int:
        """Convert priority to numeric value for sorting."""
        priorities = {'critical': 4, 'high': 3, 'medium': 2, 'low': 1, 'info': 0}
        return priorities.get(priority, 0)

    def _generate_csv_report(self, findings: List[Dict], filepath: Path):
        """Generate CSV report of vulnerabilities."""
        if not findings:
            return

        fieldnames = ['severity', 'type', 'description', 'port', 'service', 'recommendation']

        with open(filepath, 'w', newline='') as csvfile:
            writer = csv.DictWriter(csvfile, fieldnames=fieldnames)
            writer.writeheader()
            for finding in findings:
                writer.writerow({
                    'severity': finding.get('severity', ''),
                    'type': finding.get('type', ''),
                    'description': finding.get('description', ''),
                    'port': finding.get('port', ''),
                    'service': finding.get('service', ''),
                    'recommendation': finding.get('recommendation', '')
                })

    def _generate_text_report(self, report_data: Dict, filepath: Path):
        """Generate human-readable text report."""
        with open(filepath, 'w') as f:
            f.write("=" * 80 + "\n")
            f.write("AUTHORIZED RED TEAM ASSESSMENT REPORT\n")
            f.write("=" * 80 + "\n\n")

            # Metadata
            meta = report_data['report_metadata']
            f.write("REPORT INFORMATION\n")
            f.write("-" * 20 + "\n")
            f.write(f"Generated: {meta['generated_at']}\n")
            f.write(f"Assessment Type: {meta['report_type']}\n")
            f.write(f"Report Version: {meta['version']}\n\n")

            # Scope
            scope = report_data['scope']
            f.write("ASSESSMENT SCOPE\n")
            f.write("-" * 20 + "\n")
            f.write(f"Targets: {', '.join(scope.get('targets', []))}\n")
            f.write(f"Authorized Ports: {scope.get('ports', 'Default range')}\n\n")

            # Summary
            summary = report_data['summary']
            f.write("EXECUTIVE SUMMARY\n")
            f.write("-" * 20 + "\n")
            f.write(f"Total Findings: {summary['total_findings']}\n")
            f.write(f"Risk Assessment: {summary['risk_assessment']}\n\n")

            severity_dist = summary['severity_distribution']
            f.write("Finding Severity Distribution:\n")
            for severity, count in severity_dist.items():
                if count > 0:
                    f.write(f"  {severity.upper()}: {count}\n")
            f.write("\n")

            # Recommendations
            recommendations = report_data['recommendations']
            if recommendations:
                f.write("RECOMMENDATIONS\n")
                f.write("-" * 20 + "\n")
                for rec in recommendations:
                    f.write(f"[{rec['priority'].upper()}] {rec['category']}\n")
                    f.write(f"  {rec['recommendation']}\n")
                    f.write(f"  Affected Items: {rec['affected_items']}\n\n")

            # Detailed Findings
            vulnerabilities = report_data['vulnerabilities']
            if vulnerabilities:
                f.write("DETAILED FINDINGS\n")
                f.write("-" * 20 + "\n")
                for i, vuln in enumerate(vulnerabilities, 1):
                    f.write(f"{i}. [{vuln['severity'].upper()}] {vuln['description']}\n")
                    f.write(f"   Service: {vuln['service']} (Port: {vuln['port']})\n")
                    f.write(f"   Type: {vuln['type']}\n")
                    f.write(f"   Recommendation: {vuln['recommendation']}\n\n")

            f.write("=" * 80 + "\n")
            f.write("END OF REPORT\n")
            f.write("=" * 80 + "\n")