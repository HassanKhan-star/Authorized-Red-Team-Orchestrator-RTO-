"""Reconnaissance module for authorized red team operations."""

import socket
import json
import logging
from typing import Dict, List, Optional
from datetime import datetime
import ipaddress

logger = logging.getLogger(__name__)


class ScopeManager:
    """Manages authorized scope for red team operations."""

    def __init__(self, allowed_targets: List[str] = None, allowed_ports: List[int] = None):
        self.allowed_targets = allowed_targets or []
        self.allowed_ports = allowed_ports or list(range(1, 1025))  # Common ports by default

    def is_target_allowed(self, target: str) -> bool:
        """Check if target is within authorized scope."""
        try:
            target_ip = ipaddress.ip_address(target)
            for allowed in self.allowed_targets:
                if ipaddress.ip_address(allowed) == target_ip:
                    return True
                # Check CIDR ranges
                if '/' in allowed:
                    network = ipaddress.ip_network(allowed, strict=False)
                    if target_ip in network:
                        return True
        except ValueError:
            # Try hostname resolution
            try:
                resolved = socket.gethostbyname(target)
                return self.is_target_allowed(resolved)
            except socket.gaierror:
                pass
        return False

    def is_port_allowed(self, port: int) -> bool:
        """Check if port is within authorized scope."""
        return port in self.allowed_ports


class ReconnaissanceScanner:
    """Handles reconnaissance scanning operations."""

    def __init__(self, scope_manager: ScopeManager):
        self.scope_manager = scope_manager
        self.results = {}

    def port_scan(self, target: str, ports: List[int] = None) -> Dict:
        """Perform basic port scanning on target."""
        if not self.scope_manager.is_target_allowed(target):
            raise ValueError(f"Target {target} is not within authorized scope")

        ports = ports or [21, 22, 23, 25, 53, 80, 110, 135, 139, 143, 443, 445, 993, 995, 3389]
        open_ports = []

        logger.info(f"Starting port scan on {target}")

        for port in ports:
            if not self.scope_manager.is_port_allowed(port):
                logger.warning(f"Port {port} not in authorized scope, skipping")
                continue

            try:
                sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
                sock.settimeout(1)
                result = sock.connect_ex((target, port))
                if result == 0:
                    open_ports.append({
                        'port': port,
                        'service': self._identify_service(port),
                        'status': 'open'
                    })
                sock.close()
            except Exception as e:
                logger.error(f"Error scanning port {port}: {e}")

        result = {
            'target': target,
            'scan_time': datetime.now().isoformat(),
            'open_ports': open_ports,
            'total_ports_scanned': len([p for p in ports if self.scope_manager.is_port_allowed(p)])
        }

        self.results[target] = result
        return result

    def service_enumeration(self, target: str, ports: List[int] = None) -> Dict:
        """Perform basic service enumeration."""
        scan_result = self.port_scan(target, ports)
        # Enhanced service detection could be added here
        return scan_result

    def _identify_service(self, port: int) -> str:
        """Basic service identification by port number."""
        services = {
            21: 'FTP',
            22: 'SSH',
            23: 'Telnet',
            25: 'SMTP',
            53: 'DNS',
            80: 'HTTP',
            110: 'POP3',
            135: 'RPC',
            139: 'NetBIOS',
            143: 'IMAP',
            443: 'HTTPS',
            445: 'SMB',
            993: 'IMAPS',
            995: 'POP3S',
            3389: 'RDP'
        }
        return services.get(port, 'Unknown')

    def get_results(self) -> Dict:
        """Get all reconnaissance results."""
        return self.results