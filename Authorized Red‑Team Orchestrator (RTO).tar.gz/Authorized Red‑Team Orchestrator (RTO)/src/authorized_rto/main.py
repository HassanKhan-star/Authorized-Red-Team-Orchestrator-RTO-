"""Main entry point for Authorized RTO."""

import argparse
import sys
import logging
from pathlib import Path
from .modules import (
    ReconnaissanceScanner,
    ScopeManager,
    VulnerabilityScanner,
    ReportGenerator,
    ComplianceLogger
)


def setup_logging(verbose: bool = False):
    """Set up logging configuration."""
    level = logging.DEBUG if verbose else logging.INFO
    logging.basicConfig(
        level=level,
        format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
    )


def run_reconnaissance(args):
    """Run reconnaissance operations."""
    print("🔍 Starting reconnaissance operations...")

    # Initialize components
    scope_manager = ScopeManager(
        allowed_targets=args.targets,
        allowed_ports=args.ports
    )

    scanner = ReconnaissanceScanner(scope_manager)
    compliance_logger = ComplianceLogger()

    results = {}

    for target in args.targets:
        try:
            operation_id = compliance_logger.log_operation_start(
                'reconnaissance', target, 'rto_cli', args.scope_id or 'default'
            )

            # Validate scope
            compliance_logger.log_scope_validation(
                target, True, {'targets': args.targets, 'ports': args.ports}
            )

            # Perform reconnaissance
            recon_result = scanner.port_scan(target, args.ports)
            results[target] = recon_result

            compliance_logger.log_operation_complete(operation_id, recon_result)

            print(f"✅ Reconnaissance completed for {target}")
            print(f"   Open ports found: {len(recon_result['open_ports'])}")

        except Exception as e:
            print(f"❌ Error scanning {target}: {e}")
            compliance_logger.log_error(operation_id, str(e))

    return results


def run_vulnerability_scan(args):
    """Run vulnerability scanning operations."""
    print("🔎 Starting vulnerability scanning...")

    # First run reconnaissance if no recon data provided
    if not hasattr(args, 'recon_data') or not args.recon_data:
        print("No reconnaissance data provided, running recon first...")
        recon_args = argparse.Namespace(
            targets=args.targets,
            ports=args.ports,
            scope_id=args.scope_id
        )
        recon_results = run_reconnaissance(recon_args)
    else:
        recon_results = args.recon_data

    # Initialize components
    scope_manager = ScopeManager(allowed_targets=args.targets)
    vuln_scanner = VulnerabilityScanner()
    compliance_logger = ComplianceLogger()

    all_findings = []

    for target, recon_data in recon_results.items():
        try:
            operation_id = compliance_logger.log_operation_start(
                'vulnerability_scan', target, 'rto_cli', args.scope_id or 'default'
            )

            # Scan for vulnerabilities
            findings = vuln_scanner.scan_target(target, recon_data['open_ports'])

            for finding in findings:
                finding['target'] = target
                compliance_logger.log_vulnerability_found(finding, operation_id)

            all_findings.extend(findings)

            compliance_logger.log_operation_complete(operation_id, {'findings': findings})

            print(f"✅ Vulnerability scan completed for {target}")
            print(f"   Vulnerabilities found: {len(findings)}")

        except Exception as e:
            print(f"❌ Error scanning {target}: {e}")
            compliance_logger.log_error(operation_id, str(e))

    return all_findings


def generate_report(args):
    """Generate comprehensive reports."""
    print("📊 Generating reports...")

    # Load data from previous operations (in a real implementation, this would come from stored data)
    recon_results = getattr(args, 'recon_data', {})
    vuln_findings = getattr(args, 'vuln_data', [])

    scope_info = {
        'targets': args.targets or [],
        'ports': args.ports or [],
        'scope_id': args.scope_id or 'default'
    }

    operation_metadata = {
        'operator': 'rto_cli',
        'tool_version': '1.0.0',
        'assessment_type': 'authorized_red_team'
    }

    report_gen = ReportGenerator()
    report_path = report_gen.generate_comprehensive_report(
        recon_results, vuln_findings, scope_info, operation_metadata
    )

    print(f"✅ Reports generated successfully!")
    print(f"   Main report: {report_path}")

    return report_path


def run_full_assessment(args):
    """Run complete red team assessment."""
    print("🚀 Starting full red team assessment...")

    # Step 1: Reconnaissance
    recon_results = run_reconnaissance(args)

    # Step 2: Vulnerability scanning
    vuln_args = argparse.Namespace(
        targets=args.targets,
        ports=args.ports,
        scope_id=args.scope_id,
        recon_data=recon_results
    )
    vuln_findings = run_vulnerability_scan(vuln_args)

    # Step 3: Generate reports
    report_args = argparse.Namespace(
        targets=args.targets,
        ports=args.ports,
        scope_id=args.scope_id,
        recon_data=recon_results,
        vuln_data=vuln_findings
    )
    report_path = generate_report(report_args)

    print("\n🎯 Assessment completed!")
    print(f"📁 Reports available in: {Path(report_path).parent}")

    return {
        'reconnaissance': recon_results,
        'vulnerabilities': vuln_findings,
        'report_path': report_path
    }


def main():
    """Main function for the RTO CLI."""
    parser = argparse.ArgumentParser(
        description="Authorized Red-Team Orchestrator (RTO)",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  # Run full assessment
  PYTHONPATH=src python3 -m authorized_rto.main assess --targets 192.168.1.1 --scope-id PROJ-001
  # Or if installed: rto assess --targets 192.168.1.1 --scope-id PROJ-001

  # Reconnaissance only
  PYTHONPATH=src python3 -m authorized_rto.main recon --targets 192.168.1.1,192.168.1.2 --ports 80 443 --scope-id TEST-001

  # Vulnerability scan
  PYTHONPATH=src python3 -m authorized_rto.main vuln --targets 192.168.1.1 --scope-id TEST-002

  # Generate reports
  PYTHONPATH=src python3 -m authorized_rto.main report --targets 192.168.1.1 --scope-id TEST-003
        """
    )

    parser.add_argument("--version", action="version", version="Authorized RTO 1.0.0")
    parser.add_argument("-v", "--verbose", action="store_true", help="Enable verbose logging")
    parser.add_argument("--scope-id", help="Unique identifier for this assessment scope")

    subparsers = parser.add_subparsers(dest='command', help='Available commands')

    # Reconnaissance command
    recon_parser = subparsers.add_parser('recon', help='Run reconnaissance operations')
    recon_parser.add_argument('--targets', required=True,
                             help='Comma-separated list of target IPs/hostnames')
    recon_parser.add_argument('--ports', type=int, nargs='*',
                             default=[21, 22, 23, 25, 53, 80, 110, 135, 139, 143, 443, 445, 993, 995, 3389],
                             help='Ports to scan (default: common ports)')
    recon_parser.add_argument('--scope-id', help='Unique identifier for this assessment scope')

    # Vulnerability scan command
    vuln_parser = subparsers.add_parser('vuln', help='Run vulnerability scanning')
    vuln_parser.add_argument('--targets', required=True,
                            help='Comma-separated list of target IPs/hostnames')
    vuln_parser.add_argument('--ports', type=int, nargs='*',
                            default=[21, 22, 23, 25, 53, 80, 110, 135, 139, 143, 443, 445, 993, 995, 3389],
                            help='Ports to scan (default: common ports)')
    vuln_parser.add_argument('--scope-id', help='Unique identifier for this assessment scope')

    # Report generation command
    report_parser = subparsers.add_parser('report', help='Generate reports')
    report_parser.add_argument('--targets', required=True,
                              help='Comma-separated list of target IPs/hostnames')
    report_parser.add_argument('--ports', type=int, nargs='*',
                              default=[21, 22, 23, 25, 53, 80, 110, 135, 139, 143, 443, 445, 993, 995, 3389],
                              help='Ports to include in report')
    report_parser.add_argument('--scope-id', help='Unique identifier for this assessment scope')

    # Full assessment command
    assess_parser = subparsers.add_parser('assess', help='Run complete red team assessment')
    assess_parser.add_argument('--targets', required=True,
                              help='Comma-separated list of target IPs/hostnames')
    assess_parser.add_argument('--ports', type=int, nargs='*',
                              default=[21, 22, 23, 25, 53, 80, 110, 135, 139, 143, 443, 445, 993, 995, 3389],
                              help='Ports to scan (default: common ports)')
    assess_parser.add_argument('--scope-id', help='Unique identifier for this assessment scope')

    args = parser.parse_args()

    if not args.command:
        parser.print_help()
        return

    # Set up logging
    setup_logging(args.verbose)

    # Parse targets
    if hasattr(args, 'targets'):
        args.targets = [t.strip() for t in args.targets.split(',')]

    try:
        if args.command == 'recon':
            run_reconnaissance(args)
        elif args.command == 'vuln':
            run_vulnerability_scan(args)
        elif args.command == 'report':
            generate_report(args)
        elif args.command == 'assess':
            run_full_assessment(args)

    except KeyboardInterrupt:
        print("\n⚠️  Operation cancelled by user")
        sys.exit(1)
    except Exception as e:
        print(f"❌ Error: {e}")
        if args.verbose:
            import traceback
            traceback.print_exc()
        sys.exit(1)


if __name__ == "__main__":
    main()