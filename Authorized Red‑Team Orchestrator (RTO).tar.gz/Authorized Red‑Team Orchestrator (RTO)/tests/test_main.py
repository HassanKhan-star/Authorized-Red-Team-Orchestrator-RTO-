"""Tests for authorized_rto."""

import pytest
from unittest.mock import patch, MagicMock
from authorized_rto import main
from authorized_rto.modules import ScopeManager, ReconnaissanceScanner, VulnerabilityScanner


def test_main_basic():
    """Test the main function basic functionality."""
    # Test that main doesn't crash with --version
    with patch('sys.argv', ['rto', '--version']):
        try:
            main.main()
        except SystemExit:
            # --version causes SystemExit, which is expected
            pass


def test_scope_manager():
    """Test scope management functionality."""
    scope = ScopeManager(allowed_targets=['192.168.1.1'], allowed_ports=[80, 443])

    assert scope.is_target_allowed('192.168.1.1')
    assert not scope.is_target_allowed('192.168.1.2')
    assert scope.is_port_allowed(80)
    assert scope.is_port_allowed(443)
    assert not scope.is_port_allowed(22)


def test_reconnaissance_scanner():
    """Test reconnaissance scanning functionality."""
    scope = ScopeManager(allowed_targets=['127.0.0.1'], allowed_ports=[80, 443])
    scanner = ReconnaissanceScanner(scope)

    # Test with localhost (should work in most environments)
    results = scanner.port_scan('127.0.0.1', [80])

    assert 'target' in results
    assert 'scan_time' in results
    assert 'open_ports' in results
    assert isinstance(results['open_ports'], list)


def test_vulnerability_scanner():
    """Test vulnerability scanning functionality."""
    scanner = VulnerabilityScanner()

    # Mock open ports data
    open_ports = [
        {'port': 80, 'service': 'HTTP', 'status': 'open'},
        {'port': 443, 'service': 'HTTPS', 'status': 'open'}
    ]

    # Test scanning (will attempt real connections)
    findings = scanner.scan_target('127.0.0.1', open_ports)

    assert isinstance(findings, list)
    # May or may not find vulnerabilities depending on target


def test_cli_commands():
    """Test CLI command parsing."""
    # Test recon command parsing
    with patch('sys.argv', ['rto', 'recon', '--targets', '127.0.0.1']):
        with patch('authorized_rto.main.run_reconnaissance') as mock_recon:
            mock_recon.return_value = {}
            try:
                main.main()
                mock_recon.assert_called_once()
            except SystemExit:
                pass  # Expected for CLI apps

    # Test assess command parsing
    with patch('sys.argv', ['rto', 'assess', '--targets', '127.0.0.1']):
        with patch('authorized_rto.main.run_full_assessment') as mock_assess:
            mock_assess.return_value = {}
            try:
                main.main()
                mock_assess.assert_called_once()
            except SystemExit:
                pass  # Expected for CLI apps