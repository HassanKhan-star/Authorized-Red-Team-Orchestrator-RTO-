<!-- Describe the proposed changes -->

## Description
Describe the changes made and why.

## Type of change
- Bug fix
- New feature
- Documentation update

## Checklist
- I have added tests that prove my fix is effective or that my feature works
- I have added necessary documentation (if appropriate)
