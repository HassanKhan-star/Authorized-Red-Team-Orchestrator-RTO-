# Authorized Red-Team Orchestrator (RTO)

A comprehensive tool for orchestrating authorized red team operations in cybersecurity assessments. This tool provides reconnaissance, vulnerability scanning, reporting, and compliance tracking capabilities.

## ⚠️ Important Notice

**This tool is for authorized security testing only.** Use only on systems and networks where you have explicit written permission. Unauthorized use may violate laws and regulations.

## Features

- 🔍 **Reconnaissance**: Network scanning and service enumeration
- 🔎 **Vulnerability Scanning**: Automated vulnerability detection
- 📊 **Reporting**: Comprehensive assessment reports
- 📋 **Compliance Tracking**: Audit trails and scope validation
- 🛡️ **Scope Management**: Ensures operations stay within authorized boundaries

## Quick start

1. Create a virtualenv and activate it:

```bash
python -m venv .venv
source .venv/bin/activate
```

2. Install dependencies:

```bash
pip install --upgrade pip
pip install -r requirements.txt
```

3. Install the package in editable mode:

```bash
pip install -e .
```

## Usage

### Direct Python Execution

Since the tool uses Python standard library only, you can run it directly without installation:

```bash
# Full assessment (recon + vuln scan + reporting)
PYTHONPATH=src python3 -m authorized_rto.main assess --targets 192.168.1.1 --scope-id PROJ-001

# Individual operations
PYTHONPATH=src python3 -m authorized_rto.main recon --targets 192.168.1.1 --ports 80 443 --scope-id TEST-001
PYTHONPATH=src python3 -m authorized_rto.main vuln --targets 192.168.1.1 --scope-id TEST-002
PYTHONPATH=src python3 -m authorized_rto.main report --targets 192.168.1.1 --scope-id TEST-003
```

### Installed CLI (after `pip install -e .`)

If you install the package, the `rto` command becomes available:

```bash
# Full assessment (recon + vuln scan + reporting)
rto assess --targets 192.168.1.1 --scope-id PROJ-001

# Individual operations
rto recon --targets 192.168.1.1 --ports 80 443 --scope-id TEST-001
rto vuln --targets 192.168.1.1 --scope-id TEST-002
rto report --targets 192.168.1.1 --scope-id TEST-003
```

### Command Options

- `--targets`: Comma-separated list of target IPs/hostnames (required)
- `--ports`: Specific ports to scan (default: common ports 21,22,23,25,53,80,110,135,139,143,443,445,993,995,3389)
- `--scope-id`: Unique identifier for assessment scope
- `--verbose, -v`: Enable verbose logging

## Output

The tool generates multiple report formats:

- **JSON Report**: Detailed structured data (`reports/rto_report_YYYYMMDD_HHMMSS.json`)
- **CSV Report**: Vulnerability findings in spreadsheet format
- **Text Report**: Human-readable assessment summary
- **Compliance Logs**: Audit trail in `logs/` directory

## Scope Management

The tool enforces strict scope controls:

- Only specified targets can be scanned
- Only authorized ports are accessible
- All activities are logged for compliance
- Scope violations are blocked and logged

## Running Tests

```bash
PYTHONPATH=src python3 -m pytest -q
```

## Development

This project uses Python 3.8+ and follows standard Python packaging practices.

### Project Structure

```
src/authorized_rto/
├── main.py                 # CLI entry point
└── modules/
    ├── reconnaissance.py   # Network scanning
    ├── vulnerability_scanner.py  # Vulnerability detection
    ├── reporting.py        # Report generation
    └── compliance.py       # Audit logging
```

## Security Considerations

- All operations require explicit scope authorization
- Network traffic is minimized to essential scanning
- No exploitation or destructive actions are performed
- Full audit trail maintained for all activities
- SSL/TLS certificate validation follows secure practices

## Contributing

1. Ensure all changes maintain scope enforcement
2. Add comprehensive tests for new functionality
3. Update documentation for any new features
4. Follow the existing code style and patterns

## License

MIT - See LICENSE file for details.

## Disclaimer

This tool is provided as-is for authorized security testing. Users are responsible for ensuring compliance with applicable laws, regulations, and organizational policies. The authors assume no liability for misuse or unauthorized use.